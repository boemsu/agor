library(shiny)

shinyAppDir("app")
